export FT_LINE1=7
export FT_LINE2=15

./r_dwssap.sh

echo "-----------"

export FT_LINE1=13
export FT_LINE2=24

./r_dwssap.sh
