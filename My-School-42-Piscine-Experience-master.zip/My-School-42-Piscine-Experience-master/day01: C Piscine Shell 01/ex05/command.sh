touch "\"\\?\$*'MaRViN'*\$?\\\""
