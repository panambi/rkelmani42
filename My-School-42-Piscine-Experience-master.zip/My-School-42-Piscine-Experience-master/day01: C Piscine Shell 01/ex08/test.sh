# Example 1
export FT_NBR1=\\\'?\"\\\"\'\\
export FT_NBR2=rcrdmddd

./add_chelou.sh

# Example 2
export FT_NBR1='\\"\\"!\\"\\"!\\"\\"!\\"\\"!\\"\\"!\\"\\"'
export FT_NBR2=dcrcmcmooododmrrrmorcmcrmomo

./add_chelou.sh
