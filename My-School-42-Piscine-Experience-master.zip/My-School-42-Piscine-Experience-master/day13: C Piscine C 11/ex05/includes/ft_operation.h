/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_operation.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ecaceres <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/18 16:10:30 by ecaceres          #+#    #+#             */
/*   Updated: 2019/08/18 16:10:30 by ecaceres         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_OPERATION_H
# define FT_OPERATION_H

int		ft_operation_add(int a, int b);

int		ft_operation_minus(int a, int b);

int		ft_operation_devide(int a, int b);

int		ft_operation_multiply(int a, int b);

int		ft_operation_modulo(int a, int b);

#endif
