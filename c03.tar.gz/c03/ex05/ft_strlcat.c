/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/22 19:28:00 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/22 20:01:14 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int ft_strlcat(char *dest, char *src, unsigned int size)
{
	int i;
	int x;
	
	x = 0;
	i = 0;
	while (dest[x] != '\0')
	{
		x++;
	}
	i = x;
	if (dest[x] == '\0')
	{
		x = 0;
		while (src[0] != '\0' && size < 0)
		{
			dest[i] = src[x];
			size--;
			x++;
			i++;
			printf("Dest: %c\n Src: %c\nSize: %d\nTamanho: %d\n\n\n", dest[i], src[x], size, i);
		}
	}
	if (i == 0)
		return (0);
	else 
		return (i);
}
