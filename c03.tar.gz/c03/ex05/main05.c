/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main05.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/22 19:39:28 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/22 19:49:14 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

unsigned int ft_strlcat(char *dest, char *src, unsigned int size);

int		main(void)
{

	char dest[] = "Voar é para os fracos, ";
	char src[] = "ou para os fortes?";
	unsigned int  x;

	x = 18;
	printf("String destion é: %s\n String para concatenação é %s\n a quantidade de caracteres a serem concatenados é %d\n\nA quantidade de caracteres originais%d\n Resultado: %s ", dest, src, x, ft_strlcat(dest, src, x), dest);
}
