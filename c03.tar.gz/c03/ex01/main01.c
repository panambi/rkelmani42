/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 15:22:26 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/21 15:37:05 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int		ft_strncmp(char *s1, char *s2, unsigned int n);

int		main(void)
{
	char *str1;
	char *str2;
	

	str1 = "Ola";
	str2 = "Olaa";
	printf("c  : %d\n", ft_strncmp(str1, str2, 1));
	printf("ft : %d\n", ft_strncmp(str1, str2, 4));
}
