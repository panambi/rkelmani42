/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 16:54:41 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/21 17:23:28 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcat(char *dest, char *src);

int		main(void)
{
	char	dest[25] = "Mulher do ";
	char	src[25] = "fim do Mundo.";

	printf("A string de Source é: %s\nA string de destino era: %s\n", src, dest);
	ft_strcat(dest, src);
	printf("Após a concatenação a string de destino ficou: %s", dest);
}
	

