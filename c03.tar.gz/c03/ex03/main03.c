/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 16:54:41 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/21 18:52:12 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strncat(char *dest, char *src, unsigned int nb);

int		main(void)
{
	char	dest[25] = "Mulher do ";
	char	src[25] = "fim do Mundo.";
	unsigned int x;

	x = 3;
	printf("A string de Source é: %s\nA string de destino era: %s\n String de concatenação terá %d caracteres.\n", src, dest, x);
	ft_strncat(dest, src, x);
	printf("Após a concatenação a string de destino ficou: %s", dest);
}
	

