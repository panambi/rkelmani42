/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/20 16:11:48 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/21 15:26:31 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int		ft_strcmp(char *s1, char *s2);

int	main(void)
{
	char *str1;
	char *str2;

	str1 = "Ola";
	str2 = "Olaa";
	printf("c  : %d\n", ft_strcmp(str1, str2));
	printf("ft : %d\n", ft_strcmp(str1, str2));
}
