/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 18:53:06 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/22 19:27:08 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdbool.h>

char	*ft_strstr(char *str, char *to_find)
{
	char *reservstr;
	char *reservfind;

	if (*to_find == '\0')
		return (str);
	reservstr = str;
	reservfind = to_find;
	while (true)
	{
		if (*reservfind == '\0')
			return (reservstr - (reservfind - to_find));
		if (*reservstr == *reservfind)
			reservfind++;
		else
			reservfind = to_find;
		if (*reservstr == '\0')
			break ;
		reservstr++;
	}
	return (0);
}
