/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkelmani <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/22 12:21:43 by rkelmani          #+#    #+#             */
/*   Updated: 2019/10/22 19:22:21 by rkelmani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strstr(char *str, char *to_find);

int		main(void)
{
	char str[] = "A alma é um corpo flutuante.";
	char to_find[] = "corpo";

	printf("\nString str: %s\n String para busca: %s\n resultado da busca: %s", str, to_find, ft_strstr(str, to_find));
}
