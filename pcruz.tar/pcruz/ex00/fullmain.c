/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fullmain.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcruz <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/20 20:21:11 by pcruz             #+#    #+#             */
/*   Updated: 2019/10/20 20:21:14 by pcruz            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

                                                           
#include <unistd.h>
#include <fcntl.h>
#include "biblio.h"
#define BUF_SIZE 8999

char	*ft_strcpy(char *dest, char *src)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (src[i] != '\n')
	{
		if (src[i] >= 'a' && src[i] <= 'z')
		{
			dest[j] = src[i];
			j++;
		}
		i++;
	}
	dest[j] = '\0';
	return (dest);
}

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int j;

	i = 0;
	j = 0;
	if (to_find[0] == '\0')
			return (&str[i]);
	while (str[i] != '\0')
	{
		if (str[i] == to_find[0])
		{
			while (str[j + i] == to_find[j] && str[i] != '\n')
			{
				if (to_find[j + 1] == '\0')
					return (&str[i]);
				j++;
			}
		}
		i++;
	}
		return (0);
}

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}
int main(int argc, char **argv)
{
	int fd;
	int ret;
	char buf[BUF_SIZE + 1];
	char *str;
	char *str1;

	if (argc != 2)
		{
			write(1, "Error", 7);
			return (0);
		}
	/* tentando usar esse comando open */
	fd = open("dicionário.txt", O_RDONLY);
	if (fd == -1)
	{
		write(1, "Error", 6);
		return (0);
	}
		fd = open("dicionário.txt", O_RDONLY);
		ret = read(fd, buf, BUF_SIZE);
	/*ft_putstr(buf);*/
	buf[ret] = '\0';
	str = ft_strstr(buf, argv[1]);
	str1 = ft_strcpy(argv[1], str);
	ft_putstr(str1);
	return(0);
}
